=== BSU Accessibility ===
Contributors: Matt Berg, David M. Lentz
Requires at least: 4.4.2
Stable tag: 0.3.0
Tested up to: 4.4.2

Plugin for fixing minor accessibility issues programmatically.

== Description ==

Plugin for fixing minor accessibility issues programmatically.