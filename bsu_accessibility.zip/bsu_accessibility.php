<?php
/*
Plugin Name: Boise State Accessibility
Description: Plugin for fixing minor accessibility issues programmatically. Makes the following changes:
 - Adds title="Calendar" to Google Calendar iframes.
 - Adds title="Slides" to Slideshare iframes.
 - Adds title="Video" to Youtube and Vimeo and Techsmithrelay iframes.
 - Adds title="Embedded document" to Google Doc iframes.
 - Adds summary attribute to tablepress tables (using the Description provided by the table's creator).
 - Turns <b> tags into <strong> tags.
 - Turns <i> tags into <em> tags.
 - Removes empty header tags.
 - Adds a form for providing email address of a user who should receive notice of a11y errors (based on pa11y scanner)
Version: 0.3.1
Author: Matt Berg, David Lentz
*/

defined( 'ABSPATH' ) or die( 'No hackers' );

function bsu_accessibility($content){

	// As advised on this page: http://stackoverflow.com/questions/7997936/how-do-you-format-dom-structures-in-php
	libxml_use_internal_errors(true);

	$dom = new DOMDocument();
	$dom->encoding = 'utf-8';
//	$dom->loadHTML(utf8_decode($content));
	$dom->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'));
	$xpath = new DOMXPath($dom);
		
	// First, look at each iframe on the page. If it doesn't have a title, add one.
	$iframes = $dom->getElementsByTagName('iframe');
	foreach($iframes as $iframe){
		$src = $iframe->getAttribute('src');
		$iframe->removeAttribute('frameborder');
		if(!$iframe->hasAttribute('title')){
			if(strpos($src, '//calendar.google.com') !== false){
				$iframe->setAttribute('title', 'Calendar');
			} elseif(strpos($src, '//www.youtube.com') !== false){
				$iframe->setAttribute('title', 'Video');
			} elseif(strpos($src, '//player.vimeo.com') !== false){
				$iframe->setAttribute('title', 'Video');
			} elseif(strpos($src, '//boisestate.techsmithrelay.com') !== false){
				$iframe->setAttribute('title', 'Video');
			} elseif(strpos($src, '//www.slideshare.net') !== false){
				$iframe->setAttribute('title', 'Slides');
			} elseif(strpos($src, '//docs.google.com') !== false){
				$iframe->setAttribute('title', 'Embedded document');
			}
		}
	}

	// Next, look at each table. If it was created by the tablepress plugin, it should have a span that displays 
	// what the user typed in the Description field when they created the table. Grab that text and put it into the table tag
	// as a summary attribute.
    $tables = $dom->getElementsByTagName('table');
    foreach($tables as $table){
        $class = $table->getAttribute('class');
        if(strpos($class, 'tablepress') !== false){

			// Create a string that represents the class of the span we're looking for:
			// The string we're putting together here will be the class of a span (created by tablepress) whose text is what we want to use in the summary attribute of the table tag
			$target_span_class = "tablepress-table-description tablepress-table-description-id-" . substr($table->getAttribute("class"), 25);
			// We need to copy the value of the span whose class is $target_span_class and add it as a summary attribute in the corresponding opening table tag:
			$query = "//span[@class=\"$target_span_class\"]";
			$divs = $xpath->query($query);
			if ($divs) {
				$summary_value = $divs->item(0)->nodeValue; // item(0) because we just want the first (and only) one returned by $xpath->query($query);
			}

			$table->setAttribute("summary", $summary_value);

        }
    }

	// Next, find any empty header tags (e.g. <h4></h4> or <h2 class="someClass"></h2>) and remove them.
	$headerTags = array("h1", "h2", "h3", "h4", "h5", "h6");
	
	foreach ($headerTags as $headerTag) {
	
		$headersToRemove = array();

	    $headers = $dom->getElementsByTagName($headerTag);
	    foreach($headers as $header){
    		if (strlen($header->nodeValue) == 0) {
				$headersToRemove[] = $header;
			}
	    }
    
	    foreach($headersToRemove as $headerToRemove) {
		    $headerToRemove->parentNode->removeChild($headerToRemove);
		}
		
	}

	// SAVING THIS FOR A FUTURE VERSION. Does not work reliably right now:
	// A pair of A tags with only images inside them will disappear, images and all.
	// C14N may be a way to handle this, but it returns the string including the tags, 
	// which will be of varying length (because it may contain class="whatever") 
	// so we'll address that later if necessary.
/*
	// Next, find any empty a tags and remove them.	
	$aTagsToRemove = array();

    $aTags = $dom->getElementsByTagName("a");
    foreach($aTags as $aTag){
   		// if (strlen($aTag->nodeValue) == 0) {
   		if (strlen($aTag->C14N()) == 0) {
			$aTagsToRemove[] = $aTag;
		}
    }
    
	foreach($aTagsToRemove as $aTagToRemove) {
		$aTagToRemove->parentNode->removeChild($aTagToRemove);
	}


	// This is a stripped-down version of the block above. This one will just 
	// remove a pair of A tags if both the href value and node value are empty. 
	// This is happening currently when we pair Breadcrumb NavXT with Arconix FAQ.

	// Next, find any empty a tags and remove them.	
	$aTagsToRemove = array();

    $aTags = $dom->getElementsByTagName("a");
    foreach($aTags as $aTag){
   		if (strlen($aTag->getAttribute('href')) == 0) {
			$aTagsToRemove[] = $aTag;
		}
    }
    
	foreach($aTagsToRemove as $aTagToRemove) {
		$aTagToRemove->parentNode->removeChild($aTagToRemove);
	}
*/

	// Save the DOM changes: create a new string to hold the revised HTML 
	// $html = $dom->saveHTML();
	// Do it this way instead (we'd been getting a lot of errant &Acirc; chars showing up):
	// (from http://stackoverflow.com/questions/8218230/php-domdocument-loadhtml-not-encoding-utf-8-correctly)
	// $html = utf8_decode($dom->saveHTML($dom->documentElement)); 
	
	// $html = $dom->saveHTML($dom->documentElement);
	
	// This is from here: http://stackoverflow.com/questions/27442075/issues-with-dom-parsing-a-partial-html
	// ...and aims to prevent the additional DOCTYPE, HTML, and BODY tags that the previous saveHTML call adds:
	$html = preg_replace('/^<!DOCTYPE.+?>/', '', str_replace( array('<html>', '</html>', '<body>', '</body>'), array('', '', '', ''), $dom->saveHTML()));

	// Look for <b> and <i> tags and replace them with <strong> and <em>, respectively.
	$find = array("<b>", "</b>", "<i>", "</i>", "<B>", "</B>", "<I>", "</I>");
	$replace = array("<strong>", "</strong>", "<em>", "</em>", "<strong>", "</strong>", "<em>", "</em>");

	$html = str_replace($find, $replace, $html); 

	return $html;

	// As advised on this page: http://stackoverflow.com/questions/7997936/how-do-you-format-dom-structures-in-php
	if (libxml_use_internal_errors(true) === true) {
		libxml_clear_errors();
	} 	

}

// The 3rd parameter here sets the priority. It's optional and defaults to 10.
// By setting this higher, these string replacements happen *after* other plugins (like Tablepress) have done their thing.
add_filter('the_content', 'bsu_accessibility', 300);
add_filter('the_excerpt', 'bsu_accessibility', 300);


////////////////////////////////////////////////////////////
// This section creates a WordPress menu under Settings 
// to manage accessibility ("a11y") options
////////////////////////////////////////////////////////////

// Comment out this line to disable the entire Boise State A11y Options menu
add_action( 'admin_menu', 'bsu_a11y_custom_admin_menu' );
 
// add_options_page ( string $page_title, string $menu_title, string $capability, string $menu_slug, callable $function = '' )
function bsu_a11y_custom_admin_menu() {
    add_options_page(
        'Boise State a11y options',
        'Boise State a11y options',
        'manage_options',
        'bsu-a11y-plugin',
        'bsu_a11y_options_page'
    );
}

function bsu_a11y_options_page() {

   // Check that the user has the required capability 
    if (!current_user_can('manage_options'))
    {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }

	// Set the names of the form fields:
	$opt_name1 = 'a11y_contact_email';
	$opt_name2 = 'a11y_auto_scan';

	// The message to show when the form is submitted. Starts empty.
	$submitMessage = '';

	// If the form was submitted, update WordPress with the new values.
	if (isset($_POST["submitted"]) && $_POST["submitted"] == '1') {
		$opt_val1 = $_POST[$opt_name1];
		update_option ($opt_name1, $opt_val1);
		$opt_val2 = isset($_POST[$opt_name2]) ? 1 : 0;
		update_option ($opt_name2, $opt_val2);
		$submitMessage = "Settings updated. Thank you.";
	}

	// Get values from WordPress to populate the form.
	$opt_val1 = get_option( $opt_name1 );
	if (empty($opt_val1)) { 
		$opt_val1 = get_option( 'admin_email' );
	}
	$opt_val2 = get_option( $opt_name2 );

    ?>
    <div class="wrap">
        <h2>Boise State Accessibility Options</h2>
	<strong><?php echo $submitMessage; ?></strong>
	<form method="post" action="">
	<input type="hidden" name="submitted" value=1>
        <input type="checkbox" name="<?php echo $opt_name2; ?>" value=1 <?php if($opt_val2 == 1){ echo " checked"; } ?>>Automatically scan pages and posts for accessibility errors<br />
	Send notice of errors to: <input type="text" name="<?php echo $opt_name1; ?>" value="<?php echo $opt_val1; ?>" size=50><br />
	<input type="submit" value="Submit">
	</form>
    </div>
    <?php
}
